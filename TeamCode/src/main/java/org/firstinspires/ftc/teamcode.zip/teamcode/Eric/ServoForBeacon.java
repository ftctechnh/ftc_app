package org.firstinspires.ftc.teamcode.Eric;

/**
 * Created by inspirationteam on 1/22/2017.
 */

public class ServoForBeacon {
}
